import React from 'react';
import { 
  GraduationCap, 
  Moon, 
  Sun, 
  BookmarkCheck, 
  Search, 
  Compass, 
  Menu, 
  X,
  Sparkles
} from 'lucide-react';

interface NavbarProps {
  darkMode: boolean;
  setDarkMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  savedCount: number;
  onOpenSavedModal: () => void;
  onOpenSearchModal: () => void;
  activeSection: string;
  setActiveSection: (sec: string) => void;
  onSelectTool: (tool: any) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  darkMode,
  setDarkMode,
  savedCount,
  onOpenSavedModal,
  onOpenSearchModal,
  activeSection,
  setActiveSection,
  onSelectTool,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const handleNavClick = (sectionId: string) => {
    setActiveSection(sectionId);
    setMobileMenuOpen(false);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full glass-nav border-b border-slate-200/80 dark:border-slate-800/80 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand Logo */}
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => handleNavClick('hero')}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="font-outfit font-extrabold text-xl tracking-tight text-slate-900 dark:text-white">
                Edu<span className="text-blue-600 dark:text-blue-400">Navigator</span>
              </span>
              <span className="px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300 rounded-md">
                AI
              </span>
            </div>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 hidden sm:block font-medium">
              Student Success & Scholarship Planner
            </p>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center space-x-1 font-medium text-sm text-slate-600 dark:text-slate-300">
          <button
            onClick={() => handleNavClick('hero')}
            className={`px-3 py-2 rounded-lg transition-colors ${
              activeSection === 'hero' 
                ? 'text-blue-600 dark:text-blue-400 font-semibold bg-blue-50/80 dark:bg-blue-950/50' 
                : 'hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            Home
          </button>
          <button
            onClick={() => handleNavClick('tools')}
            className={`px-3 py-2 rounded-lg transition-colors flex items-center space-x-1.5 ${
              activeSection === 'tools' 
                ? 'text-blue-600 dark:text-blue-400 font-semibold bg-blue-50/80 dark:bg-blue-950/50' 
                : 'hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <Sparkles className="w-4 h-4 text-blue-500 animate-pulse" />
            <span>AI Workspace</span>
          </button>
          <button
            onClick={() => handleNavClick('features')}
            className={`px-3 py-2 rounded-lg transition-colors ${
              activeSection === 'features' 
                ? 'text-blue-600 dark:text-blue-400 font-semibold bg-blue-50/80 dark:bg-blue-950/50' 
                : 'hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            Features
          </button>
          <button
            onClick={() => handleNavClick('about')}
            className={`px-3 py-2 rounded-lg transition-colors ${
              activeSection === 'about' 
                ? 'text-blue-600 dark:text-blue-400 font-semibold bg-blue-50/80 dark:bg-blue-950/50' 
                : 'hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            About
          </button>
          <button
            onClick={() => handleNavClick('contact')}
            className={`px-3 py-2 rounded-lg transition-colors ${
              activeSection === 'contact' 
                ? 'text-blue-600 dark:text-blue-400 font-semibold bg-blue-50/80 dark:bg-blue-950/50' 
                : 'hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            Contact
          </button>
        </nav>

        {/* Right Actions: Search, Saved Modal, Dark Mode Toggle */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Search Trigger Button */}
          <button
            onClick={onOpenSearchModal}
            className="flex items-center space-x-2 text-xs sm:text-sm px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100/70 dark:bg-slate-900/70 text-slate-500 dark:text-slate-400 hover:border-blue-300 dark:hover:border-blue-700 transition-all"
            title="Search AI tools and saved plans (Ctrl+K)"
          >
            <Search className="w-4 h-4 text-slate-400" />
            <span className="hidden sm:inline">Search...</span>
            <kbd className="hidden lg:inline-block px-1.5 py-0.5 text-[10px] font-mono font-medium text-slate-400 bg-slate-200 dark:bg-slate-800 rounded">
              ⌘K
            </kbd>
          </button>

          {/* Saved Items Drawer Trigger */}
          <button
            onClick={onOpenSavedModal}
            className="relative p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70 transition-colors"
            title="View Saved AI Plans"
          >
            <BookmarkCheck className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            {savedCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-blue-600 text-white text-[11px] font-bold rounded-full flex items-center justify-center border-2 border-white dark:border-slate-950">
                {savedCount}
              </span>
            )}
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={() => setDarkMode((prev) => !prev)}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70 transition-colors"
            title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          >
            {darkMode ? (
              <Sun className="w-5 h-5 text-amber-400" />
            ) : (
              <Moon className="w-5 h-5 text-slate-600" />
            )}
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-950/95 px-4 pt-3 pb-6 space-y-2 font-medium">
          <button
            onClick={() => handleNavClick('hero')}
            className="block w-full text-left px-3 py-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-blue-50 dark:hover:bg-blue-950"
          >
            Home
          </button>
          <button
            onClick={() => handleNavClick('tools')}
            className="block w-full text-left px-3 py-2 rounded-lg text-blue-600 dark:text-blue-400 font-semibold bg-blue-50/80 dark:bg-blue-950/50"
          >
            AI Workspace (6 Tools)
          </button>
          <button
            onClick={() => handleNavClick('features')}
            className="block w-full text-left px-3 py-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-blue-50 dark:hover:bg-blue-950"
          >
            Key Features
          </button>
          <button
            onClick={() => handleNavClick('about')}
            className="block w-full text-left px-3 py-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-blue-50 dark:hover:bg-blue-950"
          >
            About & Problem
          </button>
          <button
            onClick={() => handleNavClick('contact')}
            className="block w-full text-left px-3 py-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-blue-50 dark:hover:bg-blue-950"
          >
            Contact & Support
          </button>
        </div>
      )}
    </header>
  );
};
