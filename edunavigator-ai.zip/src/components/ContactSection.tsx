import React, { useState } from 'react';
import { 
  MessageSquare, 
  Send, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  Mail, 
  MapPin, 
  CheckCircle2,
  PhoneCall
} from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [feedbackSent, setFeedbackSent] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  const faqs = [
    {
      q: 'Is EduNavigator AI specifically designed for Pakistani students?',
      a: 'Yes! EduNavigator AI is fine-tuned with deep knowledge of the Pakistani education system (Matric, FSc, ICS, A-Levels, BS degrees), Pakistani entrance exams (ECAT, MDCAT, NUST NET, FAST NU), and real national/international scholarships (HEC Need-Based, Ehsaas, PEEF, Fulbright, Chevening, DAAD).',
    },
    {
      q: 'Does EduNavigator AI invent fake scholarships or false deadlines?',
      a: 'No. The Gemini AI system prompt strictly forbids inventing fake scholarship information. It lists verified scholarship programs and reminds students to verify exact current-year cycle deadlines on official websites.',
    },
    {
      q: 'Can I download my AI study plans and scholarship checklists as PDF?',
      a: 'Yes! Every AI module output includes an instant "PDF" button that formats and downloads a clean letterhead PDF document with your name and date stamp.',
    },
    {
      q: 'Are my saved plans stored securely on my device?',
      a: 'Yes! All saved plans and conversations are persisted locally in your browser using Local Storage. You can access, filter, or delete them anytime using the Saved Plans icon in the header.',
    },
  ];

  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.message) return;
    setFeedbackSent(true);
    setTimeout(() => {
      setFeedbackSent(false);
      setFormData({ name: '', email: '', message: '' });
    }, 3000);
  };

  return (
    <section id="contact" className="py-16 md:py-24 relative bg-slate-100/60 dark:bg-slate-900/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Left Column: FAQ Accordion (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            <div>
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 text-xs font-semibold mb-2">
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Frequently Asked Questions</span>
              </div>
              <h2 className="font-outfit font-extrabold text-2xl sm:text-3xl text-slate-900 dark:text-white">
                Everything You Need to Know
              </h2>
            </div>

            <div className="space-y-3">
              {faqs.map((faq, idx) => {
                const isOpen = openFaq === idx;
                return (
                  <div
                    key={idx}
                    className="glass-card rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden transition-all"
                  >
                    <button
                      onClick={() => setOpenFaq(isOpen ? null : idx)}
                      className="w-full p-4 text-left flex items-center justify-between font-outfit font-bold text-sm text-slate-900 dark:text-white"
                    >
                      <span>{faq.q}</span>
                      {isOpen ? (
                        <ChevronUp className="w-4 h-4 text-blue-600 flex-shrink-0" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-slate-400 flex-shrink-0" />
                      )}
                    </button>

                    {isOpen && (
                      <div className="px-4 pb-4 text-xs text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-slate-800/60 pt-3">
                        {faq.a}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Contact & Feedback Form (5 cols) */}
          <div className="lg:col-span-5 glass-card rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-lg space-y-6">
            <div>
              <div className="flex items-center space-x-2 text-blue-600 dark:text-blue-400 mb-1">
                <MessageSquare className="w-5 h-5" />
                <h3 className="font-outfit font-bold text-lg text-slate-900 dark:text-white">
                  Student Feedback & Support
                </h3>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Have questions or suggestions for EduNavigator AI? Send us your message.
              </p>
            </div>

            {feedbackSent ? (
              <div className="p-6 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
                <h4 className="font-bold text-sm">Feedback Received!</h4>
                <p className="text-xs">Thank you for helping us improve EduNavigator AI for students.</p>
              </div>
            ) : (
              <form onSubmit={handleFeedbackSubmit} className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Ali Hassan"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Your Email (Optional)
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="student@example.com"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Message / Feedback *
                  </label>
                  <textarea
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Tell us what feature you would like to see..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full btn-primary py-3 rounded-xl font-bold flex items-center justify-center space-x-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Student Feedback</span>
                </button>
              </form>
            )}

            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2 text-[11px] text-slate-500 dark:text-slate-400">
              <p className="flex items-center space-x-2">
                <Mail className="w-3.5 h-3.5 text-blue-500" />
                <span>support@edunavigator.ai</span>
              </p>
              <p className="flex items-center space-x-2">
                <MapPin className="w-3.5 h-3.5 text-blue-500" />
                <span>University Campus, Islamabad / Lahore, Pakistan</span>
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
