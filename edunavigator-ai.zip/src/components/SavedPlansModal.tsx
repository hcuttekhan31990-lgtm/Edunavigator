import React, { useState } from 'react';
import { 
  X, 
  BookmarkCheck, 
  Trash2, 
  Download, 
  Copy, 
  Check, 
  Calendar, 
  Search,
  FileText
} from 'lucide-react';
import { SavedPlan } from '../types';
import { deleteSavedPlan, clearAllSavedPlans } from '../utils/storage';
import { downloadPDF } from '../utils/pdfExport';

interface SavedPlansModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedPlans: SavedPlan[];
  onPlansUpdated: () => void;
}

export const SavedPlansModal: React.FC<SavedPlansModalProps> = ({
  isOpen,
  onClose,
  savedPlans,
  onPlansUpdated,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activePlan, setActivePlan] = useState<SavedPlan | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const filteredPlans = savedPlans.filter(
    (plan) =>
      plan.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      plan.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      plan.toolType.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    deleteSavedPlan(id);
    if (activePlan?.id === id) setActivePlan(null);
    onPlansUpdated();
  };

  const handleClearAll = () => {
    if (confirm('Are you sure you want to clear all saved plans?')) {
      clearAllSavedPlans();
      setActivePlan(null);
      onPlansUpdated();
    }
  };

  const handleCopy = (plan: SavedPlan, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(plan.content);
    setCopiedId(plan.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownloadPDF = (plan: SavedPlan, e: React.MouseEvent) => {
    e.stopPropagation();
    downloadPDF(plan.title, plan.content, plan.inputsSummary);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fade-in">
      <div className="glass-card w-full max-w-4xl max-h-[85vh] rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400">
              <BookmarkCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-outfit font-bold text-lg text-slate-900 dark:text-white">
                Saved Plans & Conversations ({savedPlans.length})
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Access your locally saved AI career advice, study routines, and scholarship lists.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {savedPlans.length > 0 && (
              <button
                onClick={handleClearAll}
                className="text-xs font-semibold px-3 py-1.5 rounded-xl border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors"
              >
                Clear All
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="my-4">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Filter saved plans by keyword..."
              className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 md:grid-cols-12 gap-4 pr-1">
          
          {/* Saved List Column (5 cols) */}
          <div className="md:col-span-5 space-y-2 overflow-y-auto max-h-[480px]">
            {filteredPlans.length === 0 ? (
              <div className="py-12 text-center text-slate-400 dark:text-slate-500 text-xs">
                No saved plans match your search.
              </div>
            ) : (
              filteredPlans.map((plan) => {
                const isSelected = activePlan?.id === plan.id;
                return (
                  <div
                    key={plan.id}
                    onClick={() => setActivePlan(plan)}
                    className={`p-3.5 rounded-2xl cursor-pointer border transition-all ${
                      isSelected
                        ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-400 dark:border-blue-600 shadow-sm'
                        : 'bg-white/60 dark:bg-slate-900/60 border-slate-200/80 dark:border-slate-800 hover:border-blue-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-outfit font-bold text-xs text-slate-900 dark:text-white line-clamp-1">
                        {plan.title}
                      </h4>
                      <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 flex-shrink-0">
                        {plan.toolType}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-1">
                      {plan.inputsSummary}
                    </p>

                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-100 dark:border-slate-800/60 text-[10px] text-slate-400">
                      <span className="flex items-center space-x-1">
                        <Calendar className="w-3 h-3" />
                        <span>{plan.date}</span>
                      </span>

                      <div className="flex items-center space-x-1" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={(e) => handleCopy(plan, e)}
                          className="p-1 text-slate-400 hover:text-blue-600"
                          title="Copy"
                        >
                          {copiedId === plan.id ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                        <button
                          onClick={(e) => handleDownloadPDF(plan, e)}
                          className="p-1 text-slate-400 hover:text-blue-600"
                          title="PDF"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={(e) => handleDelete(plan.id, e)}
                          className="p-1 text-slate-400 hover:text-rose-600"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Active Detail View (7 cols) */}
          <div className="md:col-span-7 glass-card rounded-2xl p-4 border border-slate-200 dark:border-slate-800 overflow-y-auto max-h-[480px]">
            {activePlan ? (
              <div className="space-y-4 text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
                  <div>
                    <h3 className="font-outfit font-bold text-sm text-slate-900 dark:text-white">
                      {activePlan.title}
                    </h3>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      Saved on {activePlan.date}
                    </p>
                  </div>

                  <button
                    onClick={(e) => handleDownloadPDF(activePlan, e)}
                    className="btn-primary px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download PDF</span>
                  </button>
                </div>

                <div className="prose-ai text-slate-800 dark:text-slate-200 whitespace-pre-line text-xs leading-relaxed">
                  {activePlan.content}
                </div>
              </div>
            ) : (
              <div className="py-24 text-center text-slate-400 dark:text-slate-500 flex flex-col items-center justify-center space-y-2">
                <FileText className="w-8 h-8 text-slate-300 dark:text-slate-700" />
                <p className="text-xs">Select a saved plan from the left list to read or export.</p>
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
