import React, { useState, useEffect } from 'react';
import { 
  Search, 
  X, 
  Sparkles, 
  Compass, 
  Award, 
  BookOpen, 
  MapPin, 
  FileCheck2, 
  UserCheck, 
  ArrowRight,
  BookmarkCheck
} from 'lucide-react';
import { ToolType, SavedPlan } from '../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTool: (tool: ToolType) => void;
  savedPlans: SavedPlan[];
  onOpenSavedModal: () => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectTool,
  savedPlans,
  onOpenSavedModal,
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else {
          // Open trigger if handled in parent
        }
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const quickTools = [
    { id: 'career' as ToolType, title: 'AI Career Advisor', desc: 'Degree recommendations, salary forecasts, market demand in Pakistan & abroad', icon: Compass },
    { id: 'study' as ToolType, title: 'AI Study Planner', desc: 'Daily time-blocked routines, exam timetables, active recall methods', icon: BookOpen },
    { id: 'scholarship' as ToolType, title: 'AI Scholarship Assistant', desc: 'HEC, Ehsaas, PEEF, Chevening, Fulbright, DAAD document checklists', icon: Award },
    { id: 'roadmap' as ToolType, title: 'AI Skill Roadmap Generator', desc: 'Week-by-week learning paths, portfolio project ideas, free courses', icon: MapPin },
    { id: 'resume' as ToolType, title: 'AI Resume Assistant', desc: 'ATS score review out of 100, bullet rewrites, keyword optimization', icon: FileCheck2 },
    { id: 'interview' as ToolType, title: 'AI Interview Coach', desc: 'Behavioral & Technical questions, STAR answers, mock coaching', icon: UserCheck },
  ];

  const presetScholarships = [
    { name: 'HEC Need-Based Scholarship', desc: 'Tuition waiver + stipend for public university undergraduate students' },
    { name: 'Ehsaas Undergraduate Scholarship Program', desc: '100% tuition coverage for low-income Pakistani families' },
    { name: 'PEEF (Punjab Educational Endowment Fund)', desc: 'Scholarships for Matric, Intermediate & Graduation students in Punjab' },
    { name: 'Fulbright Master & PhD Scholarship (USA)', desc: 'Fully funded graduate study in the United States' },
    { name: 'Chevening Scholarship (UK)', desc: 'Fully funded one-year Master’s degree at top UK universities' },
    { name: 'DAAD Scholarship (Germany)', desc: 'Postgraduate scholarships in Germany with English-taught programs' },
  ];

  const filteredTools = quickTools.filter(
    (t) => t.title.toLowerCase().includes(query.toLowerCase()) || t.desc.toLowerCase().includes(query.toLowerCase())
  );

  const filteredScholarships = presetScholarships.filter(
    (s) => s.name.toLowerCase().includes(query.toLowerCase()) || s.desc.toLowerCase().includes(query.toLowerCase())
  );

  const filteredSaved = savedPlans.filter(
    (p) => p.title.toLowerCase().includes(query.toLowerCase()) || p.content.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 px-4 bg-slate-950/60 backdrop-blur-sm animate-fade-in">
      <div className="glass-card w-full max-w-2xl rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden space-y-4">
        
        {/* Input Bar */}
        <div className="flex items-center space-x-3 pb-3 border-b border-slate-200 dark:border-slate-800">
          <Search className="w-5 h-5 text-blue-600 dark:text-blue-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search AI tools, scholarships, or saved plans..."
            className="flex-1 bg-transparent text-sm text-slate-900 dark:text-white placeholder-slate-400 outline-none font-medium"
            autoFocus
          />
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results Container */}
        <div className="max-h-[60vh] overflow-y-auto space-y-4 pr-1 text-xs">
          
          {/* AI Tools */}
          {filteredTools.length > 0 && (
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2 px-1">
                AI Tools & Workspaces
              </span>
              <div className="space-y-1.5">
                {filteredTools.map((tool) => {
                  const IconComp = tool.icon;
                  return (
                    <div
                      key={tool.id}
                      onClick={() => {
                        onSelectTool(tool.id);
                        onClose();
                        const el = document.getElementById('tools');
                        if (el) el.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="p-3 rounded-2xl bg-white/60 dark:bg-slate-900/60 hover:bg-blue-50 dark:hover:bg-blue-950/50 border border-slate-200/80 dark:border-slate-800 cursor-pointer flex items-center justify-between transition-colors group"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="p-2 rounded-xl bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400">
                          <IconComp className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="font-bold text-slate-900 dark:text-white group-hover:text-blue-600">
                            {tool.title}
                          </h4>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400">
                            {tool.desc}
                          </p>
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition-transform" />
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Scholarships Index */}
          {filteredScholarships.length > 0 && (
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2 px-1">
                Pakistani & Global Scholarships Info
              </span>
              <div className="space-y-1.5">
                {filteredScholarships.map((sch, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      onSelectTool('scholarship');
                      onClose();
                      const el = document.getElementById('tools');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="p-3 rounded-2xl bg-white/60 dark:bg-slate-900/60 hover:bg-cyan-50 dark:hover:bg-cyan-950/50 border border-slate-200/80 dark:border-slate-800 cursor-pointer flex items-center justify-between transition-colors group"
                  >
                    <div>
                      <h4 className="font-bold text-slate-900 dark:text-white group-hover:text-cyan-600">
                        {sch.name}
                      </h4>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        {sch.desc}
                      </p>
                    </div>
                    <Sparkles className="w-4 h-4 text-cyan-500" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Saved Plans */}
          {filteredSaved.length > 0 && (
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2 px-1">
                Your Saved Plans ({filteredSaved.length})
              </span>
              <div className="space-y-1.5">
                {filteredSaved.slice(0, 3).map((plan) => (
                  <div
                    key={plan.id}
                    onClick={() => {
                      onClose();
                      onOpenSavedModal();
                    }}
                    className="p-3 rounded-2xl bg-blue-50/50 dark:bg-blue-950/30 border border-blue-200/60 dark:border-blue-900 cursor-pointer flex items-center justify-between"
                  >
                    <div className="flex items-center space-x-2">
                      <BookmarkCheck className="w-4 h-4 text-blue-600" />
                      <div>
                        <h4 className="font-bold text-slate-900 dark:text-white">
                          {plan.title}
                        </h4>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                          {plan.inputsSummary}
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] text-slate-400">{plan.date}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Footer info */}
        <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <span>Press ESC to close</span>
          <span>EduNavigator AI Search</span>
        </div>

      </div>
    </div>
  );
};
