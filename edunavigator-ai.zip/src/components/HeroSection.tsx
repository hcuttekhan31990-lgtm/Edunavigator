import React from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  Award, 
  BookOpen, 
  TrendingUp, 
  CheckCircle2,
  GraduationCap,
  Compass
} from 'lucide-react';

interface HeroSectionProps {
  onStartClick: () => void;
  onExploreClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onStartClick, onExploreClick }) => {
  return (
    <section id="hero" className="relative pt-8 pb-16 md:pt-16 md:pb-24 overflow-hidden">
      {/* Decorative Gradient Background Orbs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-blue-500/15 dark:bg-blue-600/10 rounded-full blur-3xl pointer-events-none animate-glow"></div>
      <div className="absolute top-1/3 right-10 w-[300px] h-[300px] bg-cyan-400/15 dark:bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-4xl mx-auto space-y-6">
          
          {/* Top Pill Badge */}
          <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-blue-50/90 dark:bg-blue-900/40 border border-blue-200/80 dark:border-blue-800/80 text-blue-700 dark:text-blue-300 text-xs sm:text-sm font-semibold shadow-sm">
            <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400 animate-spin-slow" />
            <span>AI Academic & Career Success Platform for Students</span>
          </div>

          {/* Main Title */}
          <h1 className="font-outfit font-extrabold text-3xl sm:text-5xl lg:text-6xl tracking-tight text-slate-900 dark:text-white leading-[1.15]">
            Navigate Your Academic Future & Scholarships with{' '}
            <span className="text-gradient-blue">Smart AI</span>
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg lg:text-xl text-slate-600 dark:text-slate-300 font-normal max-w-3xl mx-auto leading-relaxed">
            EduNavigator AI is designed specifically for students to solve real career uncertainty, study stress, and scholarship search hurdles with tailored advice, study plans, roadmaps, and resume coaching.
          </p>

          {/* Primary CTA Buttons */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={onStartClick}
              className="w-full sm:w-auto btn-primary px-8 py-4 rounded-xl font-bold text-base flex items-center justify-center space-x-2 shadow-lg shadow-blue-600/30 group"
            >
              <span>Launch AI Workspace</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={onExploreClick}
              className="w-full sm:w-auto btn-secondary px-7 py-4 rounded-xl font-semibold text-base flex items-center justify-center space-x-2"
            >
              <Compass className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <span>Explore 6 AI Features</span>
            </button>
          </div>

          {/* Key Trust Indicators */}
          <div className="pt-6 flex flex-wrap items-center justify-center gap-y-2 gap-x-6 text-xs sm:text-sm font-medium text-slate-500 dark:text-slate-400">
            <span className="flex items-center space-x-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>HEC, Ehsaas & Global Scholarships</span>
            </span>
            <span className="flex items-center space-x-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>Tailored for Matric, FSc, BS & MS</span>
            </span>
            <span className="flex items-center space-x-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>Instant PDF Export & Saved Plans</span>
            </span>
          </div>

        </div>

        {/* Feature Overview Highlights Cards Banner */}
        <div className="mt-12 sm:mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          <div className="glass-card p-5 rounded-2xl hover:border-blue-400/50 transition-all duration-300">
            <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-3">
              <GraduationCap className="w-5 h-5" />
            </div>
            <h3 className="font-outfit font-bold text-slate-900 dark:text-white text-base">Career Advisor</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Personalized career streams based on interests, FSc marks, and goals.
            </p>
          </div>

          <div className="glass-card p-5 rounded-2xl hover:border-blue-400/50 transition-all duration-300">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-3">
              <BookOpen className="w-5 h-5" />
            </div>
            <h3 className="font-outfit font-bold text-slate-900 dark:text-white text-base">AI Study Planner</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Time-blocked daily routines & active recall revision for exams.
            </p>
          </div>

          <div className="glass-card p-5 rounded-2xl hover:border-blue-400/50 transition-all duration-300">
            <div className="w-10 h-10 rounded-xl bg-cyan-100 dark:bg-cyan-900/50 text-cyan-600 dark:text-cyan-400 flex items-center justify-center mb-3">
              <Award className="w-5 h-5" />
            </div>
            <h3 className="font-outfit font-bold text-slate-900 dark:text-white text-base">Scholarships Assistant</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Verified eligibility, document checklists, and SOP preparation tips.
            </p>
          </div>

          <div className="glass-card p-5 rounded-2xl hover:border-blue-400/50 transition-all duration-300">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-3">
              <TrendingUp className="w-5 h-5" />
            </div>
            <h3 className="font-outfit font-bold text-slate-900 dark:text-white text-base">Skill Roadmaps</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Phase-by-phase learning pathways with free courses and project ideas.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
