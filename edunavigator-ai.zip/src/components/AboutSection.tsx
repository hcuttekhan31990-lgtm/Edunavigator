import React from 'react';
import { 
  GraduationCap, 
  Target, 
  ShieldCheck, 
  Cpu, 
  Code2, 
  Globe2, 
  CheckCircle2,
  BookOpen
} from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-16 md:py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Text Column */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 text-xs font-semibold">
              <Target className="w-3.5 h-3.5" />
              <span>Real Problem & Solution Statement</span>
            </div>

            <h2 className="font-outfit font-extrabold text-3xl sm:text-4xl text-slate-900 dark:text-white leading-tight">
              Solving Academic Uncertainty & Career Barriers for Students
            </h2>

            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
              Every year, thousands of Pakistani students face immense confusion after Matriculation, FSc, or Graduation. Many miss out on life-changing scholarships like HEC Need-Based, Ehsaas, or Fulbright due to lack of timely document preparation or eligibility awareness.
            </p>

            <div className="space-y-3 pt-2">
              <div className="flex items-start space-x-3 p-3 rounded-2xl bg-white/70 dark:bg-slate-900/70 border border-slate-200/80 dark:border-slate-800">
                <CheckCircle2 className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white">
                    Targeted Career & Degree Alignment
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Matches student strengths with high-demand degree programs (NUST, FAST, LUMS, UET, GIKI) and global IT/Health career markets.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 rounded-2xl bg-white/70 dark:bg-slate-900/70 border border-slate-200/80 dark:border-slate-800">
                <CheckCircle2 className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white">
                    Verified Scholarship Master Checklists
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Provides official document requirements, attestation guidelines, and Statement of Purpose (SOP) essay strategies.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 rounded-2xl bg-white/70 dark:bg-slate-900/70 border border-slate-200/80 dark:border-slate-800">
                <CheckCircle2 className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-outfit font-bold text-sm text-slate-900 dark:text-white">
                    Actionable Skill & Interview Preparation
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Generates phase-by-phase learning roadmaps, ATS resume scores, and STAR method model answers for job interviews.
                  </p>
                </div>
              </div>
            </div>

          </div>

          {/* Right Card Column: University Project Spec Card */}
          <div className="lg:col-span-5 glass-card rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-6">
            <div className="flex items-center space-x-3 border-b border-slate-200 dark:border-slate-800 pb-4">
              <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-outfit font-bold text-lg text-slate-900 dark:text-white">
                  University Final Project Spec
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  EduNavigator AI Architecture
                </p>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-100/80 dark:bg-slate-900/80">
                <span className="font-semibold text-slate-600 dark:text-slate-400 flex items-center space-x-1.5">
                  <Code2 className="w-4 h-4 text-blue-500" />
                  <span>Frontend Stack</span>
                </span>
                <span className="font-bold text-slate-900 dark:text-white">HTML5, Tailwind CSS, TypeScript</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-100/80 dark:bg-slate-900/80">
                <span className="font-semibold text-slate-600 dark:text-slate-400 flex items-center space-x-1.5">
                  <Cpu className="w-4 h-4 text-indigo-500" />
                  <span>AI Engine</span>
                </span>
                <span className="font-bold text-slate-900 dark:text-white">Google Gemini 3.6 Flash</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-100/80 dark:bg-slate-900/80">
                <span className="font-semibold text-slate-600 dark:text-slate-400 flex items-center space-x-1.5">
                  <Globe2 className="w-4 h-4 text-cyan-500" />
                  <span>Backend Architecture</span>
                </span>
                <span className="font-bold text-slate-900 dark:text-white">Express Server (Node.js)</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-100/80 dark:bg-slate-900/80">
                <span className="font-semibold text-slate-600 dark:text-slate-400 flex items-center space-x-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  <span>Key Security</span>
                </span>
                <span className="font-bold text-slate-900 dark:text-white">Server-side API Key Proxy</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-blue-50/80 dark:bg-blue-950/40 border border-blue-200/80 dark:border-blue-900 text-blue-800 dark:text-blue-200 text-xs leading-relaxed">
              <strong>Academic Note:</strong> Built as a complete, original, deployment-ready software engineering capstone demonstrating full-stack TypeScript engineering, custom prompt safety, and PDF document generation.
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
