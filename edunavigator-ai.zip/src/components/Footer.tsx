import React from 'react';
import { GraduationCap, Heart, Github, Globe } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="border-t border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-950/80 transition-colors py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white">
                <GraduationCap className="w-5 h-5" />
              </div>
              <span className="font-outfit font-extrabold text-lg text-slate-900 dark:text-white">
                Edu<span className="text-blue-600 dark:text-blue-400">Navigator</span> AI
              </span>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm leading-relaxed">
              Empowering students in Pakistan and worldwide with AI-powered career recommendations, study planners, verified scholarship checklists, and interview coaching.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-2 text-xs">
            <h4 className="font-outfit font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              AI Tools
            </h4>
            <ul className="space-y-1.5 text-slate-500 dark:text-slate-400">
              <li><a href="#tools" className="hover:text-blue-600">Career Advisor</a></li>
              <li><a href="#tools" className="hover:text-blue-600">Study Planner</a></li>
              <li><a href="#tools" className="hover:text-blue-600">Scholarship Assistant</a></li>
              <li><a href="#tools" className="hover:text-blue-600">Skill Roadmap Generator</a></li>
              <li><a href="#tools" className="hover:text-blue-600">Resume Reviewer</a></li>
            </ul>
          </div>

          {/* Project Details */}
          <div className="space-y-2 text-xs">
            <h4 className="font-outfit font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Academic Project
            </h4>
            <p className="text-slate-500 dark:text-slate-400">
              University Final Capstone Project
            </p>
            <p className="text-slate-500 dark:text-slate-400">
              Powered by Google Gemini 3.6 Flash
            </p>
            <p className="text-slate-500 dark:text-slate-400">
              Deployed on Vercel & GitHub
            </p>
          </div>

        </div>

        {/* Divider & Copyright */}
        <div className="pt-8 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 dark:text-slate-400 gap-4">
          <p className="flex items-center space-x-1">
            <span>© {new Date().getFullYear()} EduNavigator AI. Built with</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
            <span>for Pakistani & Global Students.</span>
          </p>

          <div className="flex items-center space-x-4">
            <a href="#hero" className="hover:text-blue-600">Back to Top</a>
            <span>•</span>
            <a href="#about" className="hover:text-blue-600">About Project</a>
            <span>•</span>
            <a href="#contact" className="hover:text-blue-600">Support</a>
          </div>
        </div>

      </div>
    </footer>
  );
};
