import React, { useState } from 'react';
import { 
  Compass, 
  CalendarDays, 
  Award, 
  MapPin, 
  FileCheck2, 
  UserCheck, 
  Sparkles, 
  Copy, 
  Check, 
  Download, 
  BookmarkPlus, 
  Send, 
  RotateCcw, 
  AlertCircle,
  MessageSquare,
  ChevronRight,
  Zap,
  Info
} from 'lucide-react';
import { ToolType, CareerAdvisorInputs, StudyPlannerInputs, ScholarshipAssistantInputs, SkillRoadmapInputs, ResumeAssistantInputs, InterviewCoachInputs } from '../types';
import { savePlan } from '../utils/storage';
import { downloadPDF } from '../utils/pdfExport';

interface DashboardProps {
  selectedTool: ToolType;
  setSelectedTool: (tool: ToolType) => void;
  onPlanSaved: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ selectedTool, setSelectedTool, onPlanSaved }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Response state per tool
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [typingText, setTypingText] = useState<string>('');
  const [isTyping, setIsTyping] = useState<boolean>(false);

  // Follow-up chat state
  const [followUpMsg, setFollowUpMsg] = useState('');
  const [chatHistory, setChatHistory] = useState<{ role: 'user' | 'assistant'; text: string }[]>([]);
  const [followUpLoading, setFollowUpLoading] = useState(false);

  // Form Inputs State
  const [careerInputs, setCareerInputs] = useState<CareerAdvisorInputs>({
    educationLevel: 'FSc Pre-Engineering',
    fieldOfStudy: 'Engineering / Computer Science',
    interests: 'Coding, Software Development, Artificial Intelligence, Problem Solving',
    goals: 'Build a career as a Full Stack Engineer or AI Specialist in a top tech company or study abroad on scholarship.',
    preferredLocation: 'Pakistan & Overseas (Germany / UK)',
    budgetConstraint: 'Scholarship / Need-Based Support Needed',
  });

  const [studyInputs, setStudyInputs] = useState<StudyPlannerInputs>({
    subjects: 'Physics, Chemistry, Mathematics, Computer Science',
    targetExam: 'FSc Board Exams & NUST NET / FAST Entrance Test',
    examDate: 'In 2 Months',
    availableDailyHours: '6',
    learningStyle: 'Visual & Practice Past Papers',
    weakAreas: 'Integration in Calculus & Organic Chemistry mechanisms',
  });

  const [scholarshipInputs, setScholarshipInputs] = useState<ScholarshipAssistantInputs>({
    educationLevel: 'Undergraduate (BS Computer Science)',
    currentGPA: '3.6 / 4.0 (or 85% Marks in HSSC)',
    targetDegree: 'BS CS or MS Data Science',
    targetCountry: 'Pakistan / UK / Germany / USA',
    financialNeed: 'High Financial Need (Household Income under PKR 80,000/month)',
    fieldOfInterest: 'Information Technology & STEM',
  });

  const [roadmapInputs, setRoadmapInputs] = useState<SkillRoadmapInputs>({
    targetRole: 'Full Stack Web Developer (React & Node.js)',
    currentSkillLevel: 'Beginner (Basic HTML/CSS & Python)',
    timeframeMonths: '3',
    weeklyHours: '12',
  });

  const [resumeInputs, setResumeInputs] = useState<ResumeAssistantInputs>({
    resumeText: `AHMAD KHAN
Email: ahmad.khan@example.com | Phone: +92 300 1234567 | Lahore, Pakistan
LinkedIn: linkedin.com/in/ahmadkhan | GitHub: github.com/ahmadkhan

EDUCATION
BS Computer Science, Punjab University, Lahore (Expected 2026) — GPA: 3.5/4.0
FSc Pre-Engineering, Government College Lahore (2022) — 88% Marks

PROJECTS
1. Student Management Portal: Built a portal using HTML, CSS, JavaScript and Node.js for managing student records.
2. E-Commerce Web App: Developed a basic shopping app with product listings and shopping cart.

SKILLS
Programming: C++, JavaScript, Python, HTML5, CSS3
Tools: VS Code, Git, GitHub
Languages: English (Fluent), Urdu (Native)`,
    targetJobTitle: 'Associate Software Engineer / Web Development Intern',
    experienceLevel: 'Fresh Graduate / Final Year Student',
  });

  const [interviewInputs, setInterviewInputs] = useState<InterviewCoachInputs>({
    jobRole: 'Junior Full Stack Developer',
    field: 'Software Development / IT Services',
    difficulty: 'Entry Level',
    customTopic: 'JavaScript ES6, React Fundamentals, Data Structures & Behavioral Questions',
  });

  // Effect for typing animation effect when AI response is set
  React.useEffect(() => {
    if (!aiResponse) {
      setTypingText('');
      return;
    }

    setIsTyping(true);
    let i = 0;
    const step = Math.max(1, Math.floor(aiResponse.length / 80)); // Type smoothly in chunks
    setTypingText('');

    const interval = setInterval(() => {
      i += step;
      if (i >= aiResponse.length) {
        setTypingText(aiResponse);
        setIsTyping(false);
        clearInterval(interval);
      } else {
        setTypingText(aiResponse.slice(0, i));
      }
    }, 15);

    return () => clearInterval(interval);
  }, [aiResponse]);

  const handleToolChange = (tool: ToolType) => {
    setSelectedTool(tool);
    setError(null);
    setAiResponse(null);
    setChatHistory([]);
  };

  const handleCopyResponse = () => {
    if (!aiResponse) return;
    navigator.clipboard.writeText(aiResponse);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSavePlan = () => {
    if (!aiResponse) return;
    let title = 'EduNavigator AI Plan';
    let summary = '';

    if (selectedTool === 'career') {
      title = `Career Advice: ${careerInputs.educationLevel}`;
      summary = `${careerInputs.fieldOfStudy} - ${careerInputs.goals}`;
    } else if (selectedTool === 'study') {
      title = `Study Plan: ${studyInputs.targetExam}`;
      summary = `${studyInputs.subjects} (${studyInputs.availableDailyHours} hrs/day)`;
    } else if (selectedTool === 'scholarship') {
      title = `Scholarship Advice: ${scholarshipInputs.targetDegree}`;
      summary = `${scholarshipInputs.targetCountry} - GPA: ${scholarshipInputs.currentGPA}`;
    } else if (selectedTool === 'roadmap') {
      title = `Skill Roadmap: ${roadmapInputs.targetRole}`;
      summary = `${roadmapInputs.timeframeMonths} Months (${roadmapInputs.currentSkillLevel})`;
    } else if (selectedTool === 'resume') {
      title = `Resume Review: ${resumeInputs.targetJobTitle}`;
      summary = `${resumeInputs.experienceLevel}`;
    } else if (selectedTool === 'interview') {
      title = `Interview Prep: ${interviewInputs.jobRole}`;
      summary = `${interviewInputs.field} (${interviewInputs.difficulty})`;
    }

    savePlan(selectedTool, title, aiResponse, summary);
    onPlanSaved();
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleDownloadPDF = () => {
    if (!aiResponse) return;
    const titleMap: Record<ToolType, string> = {
      career: 'AI Career Guidance Plan',
      study: 'Personalized AI Study Schedule',
      scholarship: 'Scholarships & Grants Master Guide',
      roadmap: 'Skill Mastery & Portfolio Roadmap',
      resume: 'Resume Audit & ATS Optimization Report',
      interview: 'Interview Preparation & Model Answers',
    };
    downloadPDF(titleMap[selectedTool], aiResponse, `Generated for ${selectedTool} module`);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setAiResponse(null);
    setChatHistory([]);

    const endpointMap: Record<ToolType, string> = {
      career: '/api/ai/career-advisor',
      study: '/api/ai/study-planner',
      scholarship: '/api/ai/scholarship-assistant',
      roadmap: '/api/ai/skill-roadmap',
      resume: '/api/ai/resume-assistant',
      interview: '/api/ai/interview-coach',
    };

    let bodyData: any = {};
    if (selectedTool === 'career') bodyData = careerInputs;
    else if (selectedTool === 'study') bodyData = studyInputs;
    else if (selectedTool === 'scholarship') bodyData = scholarshipInputs;
    else if (selectedTool === 'roadmap') bodyData = roadmapInputs;
    else if (selectedTool === 'resume') bodyData = resumeInputs;
    else if (selectedTool === 'interview') bodyData = interviewInputs;

    try {
      const res = await fetch(endpointMap[selectedTool], {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bodyData),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to generate AI advice. Please check inputs.');
      }

      setAiResponse(data.result);
    } catch (err: any) {
      console.error('AI Generation Error:', err);
      setError(err.message || 'An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleFollowUpSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!followUpMsg.trim() || !aiResponse) return;

    const userText = followUpMsg.trim();
    setFollowUpMsg('');
    const newHistory = [...chatHistory, { role: 'user' as const, text: userText }];
    setChatHistory(newHistory);
    setFollowUpLoading(true);

    try {
      const res = await fetch('/api/ai/general-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userText,
          context: `Original Plan Response: ${aiResponse.slice(0, 1000)}`,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to send follow-up message.');

      setChatHistory([...newHistory, { role: 'assistant', text: data.result }]);
    } catch (err: any) {
      setChatHistory([...newHistory, { role: 'assistant', text: 'Error: ' + err.message }]);
    } finally {
      setFollowUpLoading(false);
    }
  };

  // Preset fill helpers for quick user convenience
  const applyPreset = (presetName: string) => {
    if (selectedTool === 'career') {
      if (presetName === 'fsc_cs') {
        setCareerInputs({
          educationLevel: 'FSc Pre-Engineering / ICS',
          fieldOfStudy: 'Computer Science & Software Engineering',
          interests: 'Web development, mobile apps, video games, robotics',
          goals: 'Secure admission in FAST-NUCES or NUST and work as a Software Engineer.',
          preferredLocation: 'Lahore / Islamabad / Remote Global',
          budgetConstraint: 'Moderate - Need Merit / Need-Based Scholarship',
        });
      } else if (presetName === 'medical') {
        setCareerInputs({
          educationLevel: 'FSc Pre-Medical',
          fieldOfStudy: 'Medicine, Biotechnology, Biomedical Sciences or Health Tech',
          interests: 'Human biology, patient care, research, genetics, medical technology',
          goals: 'Become a Doctor (MBBS) or pursue Biotechnology & Health IT research.',
          preferredLocation: 'Pakistan / UK',
          budgetConstraint: 'Need Government University Admission or Scholarship',
        });
      }
    } else if (selectedTool === 'scholarship') {
      if (presetName === 'hec_need') {
        setScholarshipInputs({
          educationLevel: 'Undergraduate BS Degree',
          currentGPA: '82% Marks in FSc',
          targetDegree: 'BS Software Engineering',
          targetCountry: 'Pakistan (Public / Partner Universities)',
          financialNeed: 'High Need - Household Income PKR 65,000/month',
          fieldOfInterest: 'Engineering & Technology',
        });
      } else if (presetName === 'fulbright') {
        setScholarshipInputs({
          educationLevel: 'Graduating BS CS Student',
          currentGPA: '3.7 / 4.0 GPA',
          targetDegree: 'MS / PhD in Artificial Intelligence',
          targetCountry: 'United States of America (USA)',
          financialNeed: 'Full Overseas Scholarship Required',
          fieldOfInterest: 'Computer Science & Data Analytics',
        });
      }
    }
  };

  const toolTabs = [
    { id: 'career' as ToolType, label: 'Career Advisor', icon: Compass, badge: 'Popular' },
    { id: 'study' as ToolType, label: 'Study Planner', icon: CalendarDays, badge: 'Daily/Weekly' },
    { id: 'scholarship' as ToolType, label: 'Scholarships', icon: Award, badge: 'HEC/Global' },
    { id: 'roadmap' as ToolType, label: 'Skill Roadmap', icon: MapPin, badge: 'Step-by-Step' },
    { id: 'resume' as ToolType, label: 'Resume Review', icon: FileCheck2, badge: 'ATS Scoring' },
    { id: 'interview' as ToolType, label: 'Interview Prep', icon: UserCheck, badge: 'Mock Q&A' },
  ];

  return (
    <section id="tools" className="py-12 md:py-16 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Workspace Title & Tool Selector Navigation Bar */}
        <div className="mb-8 text-center sm:text-left flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 text-xs font-semibold mb-2">
              <Zap className="w-3.5 h-3.5" />
              <span>Interactive AI Workspace</span>
            </div>
            <h2 className="font-outfit font-extrabold text-2xl sm:text-3xl text-slate-900 dark:text-white">
              Student Planning & AI Assistant
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Select an AI advisor module below and enter your details to generate custom guidance.
            </p>
          </div>

          {/* Preset Buttons for Instant Testing */}
          {(selectedTool === 'career' || selectedTool === 'scholarship') && (
            <div className="flex items-center space-x-2 text-xs font-medium self-center md:self-auto">
              <span className="text-slate-500 dark:text-slate-400">Quick Presets:</span>
              {selectedTool === 'career' && (
                <>
                  <button
                    onClick={() => applyPreset('fsc_cs')}
                    className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300 border border-blue-200 dark:border-blue-800 hover:bg-blue-100"
                  >
                    FSc CS / Pre-Eng
                  </button>
                  <button
                    onClick={() => applyPreset('medical')}
                    className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100"
                  >
                    Pre-Medical
                  </button>
                </>
              )}
              {selectedTool === 'scholarship' && (
                <>
                  <button
                    onClick={() => applyPreset('hec_need')}
                    className="px-2.5 py-1 rounded-lg bg-cyan-50 text-cyan-700 dark:bg-cyan-950 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-800 hover:bg-cyan-100"
                  >
                    HEC / Ehsaas Need
                  </button>
                  <button
                    onClick={() => applyPreset('fulbright')}
                    className="px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-100"
                  >
                    Fulbright Overseas
                  </button>
                </>
              )}
            </div>
          )}
        </div>

        {/* Navigation Tabs Bar */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-3 mb-8 no-scrollbar scroll-smooth">
          {toolTabs.map((tab) => {
            const IconComp = tab.icon;
            const active = selectedTool === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => handleToolChange(tab.id)}
                className={`flex-shrink-0 flex items-center space-x-2 px-4 py-3 rounded-2xl font-semibold text-xs sm:text-sm transition-all duration-200 border ${
                  active
                    ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/25 scale-[1.02]'
                    : 'glass-card text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border-slate-200/80 dark:border-slate-800'
                }`}
              >
                <IconComp className={`w-4 h-4 ${active ? 'text-white' : 'text-blue-600 dark:text-blue-400'}`} />
                <span>{tab.label}</span>
                <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                  active ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                }`}>
                  {tab.badge}
                </span>
              </button>
            );
          })}
        </div>

        {/* Main Workspace Card Container */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Form Controls (5 cols) */}
          <div className="lg:col-span-5 glass-card rounded-3xl p-6 border border-slate-200/90 dark:border-slate-800/90 shadow-sm">
            <div className="flex items-center space-x-2 mb-6 pb-4 border-b border-slate-200 dark:border-slate-800">
              <Sparkles className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <h3 className="font-outfit font-bold text-lg text-slate-900 dark:text-white">
                Input Your Details
              </h3>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Tool 1: Career Advisor Form */}
              {selectedTool === 'career' && (
                <>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Current Education Level *
                    </label>
                    <select
                      value={careerInputs.educationLevel}
                      onChange={(e) => setCareerInputs({ ...careerInputs, educationLevel: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                    >
                      <option value="Matriculation (Science/Arts)">Matriculation (Science/Arts)</option>
                      <option value="FSc Pre-Medical">FSc Pre-Medical</option>
                      <option value="FSc Pre-Engineering">FSc Pre-Engineering</option>
                      <option value="ICS (Computer Science)">ICS (Computer Science)</option>
                      <option value="I.Com / Commerce">I.Com / Commerce</option>
                      <option value="A-Levels / O-Levels">A-Levels / O-Levels</option>
                      <option value="Undergraduate (BS/BE) Student">Undergraduate (BS/BE) Student</option>
                      <option value="Master / MS Degree">Master / MS Degree</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Field / Stream of Interest *
                    </label>
                    <input
                      type="text"
                      value={careerInputs.fieldOfStudy}
                      onChange={(e) => setCareerInputs({ ...careerInputs, fieldOfStudy: e.target.value })}
                      placeholder="e.g. Computer Science, Medicine, CA, Business, AI"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Interests & Hobbies *
                    </label>
                    <textarea
                      rows={3}
                      value={careerInputs.interests}
                      onChange={(e) => setCareerInputs({ ...careerInputs, interests: e.target.value })}
                      placeholder="What do you enjoy doing? e.g. Coding, design, biology, debate, mechanics..."
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Future Career Goals *
                    </label>
                    <textarea
                      rows={2}
                      value={careerInputs.goals}
                      onChange={(e) => setCareerInputs({ ...careerInputs, goals: e.target.value })}
                      placeholder="e.g. Become a software architect, doctor, entrepreneur..."
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Preferred Location
                      </label>
                      <input
                        type="text"
                        value={careerInputs.preferredLocation}
                        onChange={(e) => setCareerInputs({ ...careerInputs, preferredLocation: e.target.value })}
                        placeholder="Pakistan / Overseas"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Budget Status
                      </label>
                      <input
                        type="text"
                        value={careerInputs.budgetConstraint}
                        onChange={(e) => setCareerInputs({ ...careerInputs, budgetConstraint: e.target.value })}
                        placeholder="Scholarship / Flexible"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                    </div>
                  </div>
                </>
              )}

              {/* Tool 2: Study Planner Form */}
              {selectedTool === 'study' && (
                <>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Subjects / Courses to Prepare *
                    </label>
                    <input
                      type="text"
                      value={studyInputs.subjects}
                      onChange={(e) => setStudyInputs({ ...studyInputs, subjects: e.target.value })}
                      placeholder="e.g. Physics, Math, Chemistry, Computer Science"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Target Exam / Board
                      </label>
                      <input
                        type="text"
                        value={studyInputs.targetExam}
                        onChange={(e) => setStudyInputs({ ...studyInputs, targetExam: e.target.value })}
                        placeholder="e.g. FSc Board / NUST NET"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Exam Date / Timeframe
                      </label>
                      <input
                        type="text"
                        value={studyInputs.examDate}
                        onChange={(e) => setStudyInputs({ ...studyInputs, examDate: e.target.value })}
                        placeholder="e.g. In 2 Months"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Daily Hours Available *
                      </label>
                      <select
                        value={studyInputs.availableDailyHours}
                        onChange={(e) => setStudyInputs({ ...studyInputs, availableDailyHours: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      >
                        <option value="2">2 Hours / day</option>
                        <option value="4">4 Hours / day</option>
                        <option value="6">6 Hours / day</option>
                        <option value="8">8 Hours / day</option>
                        <option value="10">10+ Hours / day</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Preferred Learning Style
                      </label>
                      <select
                        value={studyInputs.learningStyle}
                        onChange={(e) => setStudyInputs({ ...studyInputs, learningStyle: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      >
                        <option value="Visual & Practice Past Papers">Visual & Past Papers</option>
                        <option value="Active Recall & Flashcards">Active Recall & Flashcards</option>
                        <option value="Pomodoro (25m study/5m break)">Pomodoro Technique</option>
                        <option value="Concept-first Feynman Technique">Feynman Method</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Weak Subjects / Specific Topics
                    </label>
                    <textarea
                      rows={2}
                      value={studyInputs.weakAreas}
                      onChange={(e) => setStudyInputs({ ...studyInputs, weakAreas: e.target.value })}
                      placeholder="e.g. Calculus integration, Organic chemistry, physics numericals..."
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </>
              )}

              {/* Tool 3: Scholarship Assistant Form */}
              {selectedTool === 'scholarship' && (
                <>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Education Level & Qualification
                    </label>
                    <input
                      type="text"
                      value={scholarshipInputs.educationLevel}
                      onChange={(e) => setScholarshipInputs({ ...scholarshipInputs, educationLevel: e.target.value })}
                      placeholder="e.g. FSc Pre-Eng or BS CS"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Current GPA / Marks %
                      </label>
                      <input
                        type="text"
                        value={scholarshipInputs.currentGPA}
                        onChange={(e) => setScholarshipInputs({ ...scholarshipInputs, currentGPA: e.target.value })}
                        placeholder="e.g. 3.6 GPA or 85%"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Target Degree
                      </label>
                      <input
                        type="text"
                        value={scholarshipInputs.targetDegree}
                        onChange={(e) => setScholarshipInputs({ ...scholarshipInputs, targetDegree: e.target.value })}
                        placeholder="e.g. BS / MS Computer Science"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Target Country / Region
                    </label>
                    <input
                      type="text"
                      value={scholarshipInputs.targetCountry}
                      onChange={(e) => setScholarshipInputs({ ...scholarshipInputs, targetCountry: e.target.value })}
                      placeholder="e.g. Pakistan (HEC/Ehsaas/PEEF), UK, Germany, USA, Turkey"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Financial Need & Category
                    </label>
                    <input
                      type="text"
                      value={scholarshipInputs.financialNeed}
                      onChange={(e) => setScholarshipInputs({ ...scholarshipInputs, financialNeed: e.target.value })}
                      placeholder="e.g. Need-Based / Merit-Based / Full Funded"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </>
              )}

              {/* Tool 4: Skill Roadmap Form */}
              {selectedTool === 'roadmap' && (
                <>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Target Career Role / Skill *
                    </label>
                    <input
                      type="text"
                      value={roadmapInputs.targetRole}
                      onChange={(e) => setRoadmapInputs({ ...roadmapInputs, targetRole: e.target.value })}
                      placeholder="e.g. Full Stack Developer, Data Scientist, Cyber Security, UX Designer"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Current Level
                      </label>
                      <select
                        value={roadmapInputs.currentSkillLevel}
                        onChange={(e) => setRoadmapInputs({ ...roadmapInputs, currentSkillLevel: e.target.value })}
                        className="w-full px-2 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      >
                        <option value="Absolute Beginner">Beginner</option>
                        <option value="Intermediate">Intermediate</option>
                        <option value="Advanced">Advanced</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Months
                      </label>
                      <select
                        value={roadmapInputs.timeframeMonths}
                        onChange={(e) => setRoadmapInputs({ ...roadmapInputs, timeframeMonths: e.target.value })}
                        className="w-full px-2 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      >
                        <option value="1">1 Month</option>
                        <option value="3">3 Months</option>
                        <option value="6">6 Months</option>
                        <option value="12">1 Year</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Weekly Hrs
                      </label>
                      <select
                        value={roadmapInputs.weeklyHours}
                        onChange={(e) => setRoadmapInputs({ ...roadmapInputs, weeklyHours: e.target.value })}
                        className="w-full px-2 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      >
                        <option value="5">5 Hrs/wk</option>
                        <option value="10">10 Hrs/wk</option>
                        <option value="20">20 Hrs/wk</option>
                      </select>
                    </div>
                  </div>
                </>
              )}

              {/* Tool 5: Resume Assistant Form */}
              {selectedTool === 'resume' && (
                <>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Target Job Title
                      </label>
                      <input
                        type="text"
                        value={resumeInputs.targetJobTitle}
                        onChange={(e) => setResumeInputs({ ...resumeInputs, targetJobTitle: e.target.value })}
                        placeholder="e.g. Software Engineer Intern"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Experience Level
                      </label>
                      <input
                        type="text"
                        value={resumeInputs.experienceLevel}
                        onChange={(e) => setResumeInputs({ ...resumeInputs, experienceLevel: e.target.value })}
                        placeholder="e.g. Student / Fresh Graduate"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Paste Resume Text or Draft *
                    </label>
                    <textarea
                      rows={8}
                      value={resumeInputs.resumeText}
                      onChange={(e) => setResumeInputs({ ...resumeInputs, resumeText: e.target.value })}
                      placeholder="Paste your resume content, experience, education, and project bullet points here..."
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      required
                    />
                  </div>
                </>
              )}

              {/* Tool 6: Interview Coach Form */}
              {selectedTool === 'interview' && (
                <>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Target Role / Job Position *
                    </label>
                    <input
                      type="text"
                      value={interviewInputs.jobRole}
                      onChange={(e) => setInterviewInputs({ ...interviewInputs, jobRole: e.target.value })}
                      placeholder="e.g. Junior Web Developer, Financial Analyst, MBBS Residency"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Industry / Domain
                      </label>
                      <input
                        type="text"
                        value={interviewInputs.field}
                        onChange={(e) => setInterviewInputs({ ...interviewInputs, field: e.target.value })}
                        placeholder="e.g. IT, Banking, Healthcare"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Difficulty Level
                      </label>
                      <select
                        value={interviewInputs.difficulty}
                        onChange={(e) => setInterviewInputs({ ...interviewInputs, difficulty: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      >
                        <option value="Entry Level">Entry Level / Internship</option>
                        <option value="Mid Level">Mid Level (1-3 yrs)</option>
                        <option value="University Admission / Scholarship">University / Scholarship Interview</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Specific Focus / Topics
                    </label>
                    <input
                      type="text"
                      value={interviewInputs.customTopic}
                      onChange={(e) => setInterviewInputs({ ...interviewInputs, customTopic: e.target.value })}
                      placeholder="e.g. OOP, System Design, Behavioral, Problem Solving"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading}
                className="w-full mt-4 btn-primary py-3.5 px-6 rounded-xl font-bold text-sm flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Consulting EduNavigator AI...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-white" />
                    <span>Generate AI Plan & Guidance</span>
                  </>
                )}
              </button>

            </form>
          </div>

          {/* Right Column: AI Output & Response Workspace (7 cols) */}
          <div className="lg:col-span-7 glass-card rounded-3xl p-6 border border-slate-200/90 dark:border-slate-800/90 shadow-sm min-h-[520px] flex flex-col justify-between">
            
            {/* Header Toolbar */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800 mb-4 flex-wrap gap-2">
              <div className="flex items-center space-x-2">
                <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></span>
                <h3 className="font-outfit font-bold text-lg text-slate-900 dark:text-white">
                  AI Output Workspace
                </h3>
              </div>

              {/* Action Toolbar for Copy, Save, PDF Download */}
              {aiResponse && (
                <div className="flex items-center space-x-2 text-xs">
                  <button
                    onClick={handleCopyResponse}
                    className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center space-x-1"
                    title="Copy AI Response"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4 text-slate-500" />}
                    <span className="hidden sm:inline">{copied ? 'Copied!' : 'Copy'}</span>
                  </button>

                  <button
                    onClick={handleSavePlan}
                    className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center space-x-1"
                    title="Save Plan to Local Storage"
                  >
                    {savedSuccess ? <Check className="w-4 h-4 text-blue-500" /> : <BookmarkPlus className="w-4 h-4 text-blue-500" />}
                    <span className="hidden sm:inline">{savedSuccess ? 'Saved!' : 'Save Plan'}</span>
                  </button>

                  <button
                    onClick={handleDownloadPDF}
                    className="p-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 flex items-center space-x-1 font-semibold"
                    title="Download as PDF Document"
                  >
                    <Download className="w-4 h-4" />
                    <span className="hidden sm:inline">PDF</span>
                  </button>
                </div>
              )}
            </div>

            {/* Error Display */}
            {error && (
              <div className="p-4 mb-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 flex items-start space-x-3 text-xs sm:text-sm">
                <AlertCircle className="w-5 h-5 text-rose-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">Generation Failed</p>
                  <p className="mt-0.5">{error}</p>
                </div>
              </div>
            )}

            {/* Loading Placeholder */}
            {loading && (
              <div className="py-20 flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                <div>
                  <p className="font-outfit font-bold text-slate-800 dark:text-slate-200 text-base">
                    Analyzing Student Profile with Gemini AI...
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Generating structured advice, Pakistani university criteria, and scholarship checklists.
                  </p>
                </div>
              </div>
            )}

            {/* Empty State when no response yet */}
            {!loading && !aiResponse && !error && (
              <div className="py-20 flex flex-col items-center justify-center text-center space-y-3 text-slate-400 dark:text-slate-500">
                <div className="w-16 h-16 rounded-2xl bg-blue-50 dark:bg-blue-950/50 flex items-center justify-center text-blue-500">
                  <Compass className="w-8 h-8" />
                </div>
                <p className="font-outfit font-semibold text-slate-700 dark:text-slate-300 text-base">
                  Ready to Generate Your Personalized Plan
                </p>
                <p className="text-xs max-w-sm">
                  Fill in your academic background and goals on the left, then click "Generate AI Plan".
                </p>
              </div>
            )}

            {/* AI Response Output */}
            {!loading && aiResponse && (
              <div className="space-y-6 overflow-y-auto max-h-[580px] pr-2">
                <div id="printable-content" className="prose-ai text-slate-800 dark:text-slate-200 whitespace-pre-line">
                  {typingText}
                  {isTyping && <span className="typing-cursor"></span>}
                </div>

                {/* Follow-up Interactive Question Box */}
                {!isTyping && (
                  <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-4">
                    <div className="flex items-center space-x-2 text-xs font-bold text-slate-700 dark:text-slate-300">
                      <MessageSquare className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                      <span>Have a Follow-up Question or Need Clarification?</span>
                    </div>

                    {/* Chat Messages */}
                    {chatHistory.length > 0 && (
                      <div className="space-y-3 max-h-60 overflow-y-auto text-xs p-3 rounded-2xl bg-slate-100/70 dark:bg-slate-900/70">
                        {chatHistory.map((item, idx) => (
                          <div
                            key={idx}
                            className={`p-2.5 rounded-xl ${
                              item.role === 'user'
                                ? 'bg-blue-600 text-white ml-6 font-medium'
                                : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 mr-6 border border-slate-200 dark:border-slate-700 whitespace-pre-line'
                            }`}
                          >
                            <span className="font-bold text-[10px] block opacity-75 mb-0.5">
                              {item.role === 'user' ? 'You:' : 'EduNavigator AI:'}
                            </span>
                            {item.text}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Chat Form */}
                    <form onSubmit={handleFollowUpSend} className="flex items-center space-x-2">
                      <input
                        type="text"
                        value={followUpMsg}
                        onChange={(e) => setFollowUpMsg(e.target.value)}
                        placeholder="Ask EduNavigator to expand on specific points..."
                        className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                      <button
                        type="submit"
                        disabled={followUpLoading || !followUpMsg.trim()}
                        className="px-4 py-2.5 rounded-xl btn-primary font-bold text-xs flex items-center space-x-1 disabled:opacity-50"
                      >
                        {followUpLoading ? (
                          <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        ) : (
                          <Send className="w-3.5 h-3.5" />
                        )}
                        <span>Ask</span>
                      </button>
                    </form>
                  </div>
                )}
              </div>
            )}

            {/* Bottom Note */}
            <div className="pt-4 text-[11px] text-slate-400 dark:text-slate-500 flex items-center space-x-1">
              <Info className="w-3.5 h-3.5 flex-shrink-0" />
              <span>EduNavigator AI offers academic guidance. Always verify official admission dates on university/scholarship portals.</span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
