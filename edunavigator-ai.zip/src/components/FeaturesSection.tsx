import React from 'react';
import { 
  Compass, 
  CalendarDays, 
  Award, 
  MapPin, 
  FileCheck2, 
  UserCheck, 
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { ToolType } from '../types';

interface FeaturesSectionProps {
  onSelectTool: (tool: ToolType) => void;
}

export const FeaturesSection: React.FC<FeaturesSectionProps> = ({ onSelectTool }) => {
  const features = [
    {
      id: 'career' as ToolType,
      title: 'AI Career Advisor',
      icon: Compass,
      color: 'from-blue-500 to-indigo-600',
      bgColor: 'bg-blue-50 dark:bg-blue-950/40',
      textColor: 'text-blue-600 dark:text-blue-400',
      borderColor: 'border-blue-200 dark:border-blue-800',
      description: 'Get structured career path recommendations based on your education stream, interests, Pakistani market demand, and overseas prospects.',
      highlights: ['Matric / FSc / A-Level Stream guidance', 'Top university degree options in Pakistan', 'Salary trends & market demand'],
    },
    {
      id: 'study' as ToolType,
      title: 'AI Study Planner',
      icon: CalendarDays,
      color: 'from-indigo-500 to-violet-600',
      bgColor: 'bg-indigo-50 dark:bg-indigo-950/40',
      textColor: 'text-indigo-600 dark:text-indigo-400',
      borderColor: 'border-indigo-200 dark:border-indigo-800',
      description: 'Generate realistic daily time-blocked study routines, subject revision cycles, and scientifically proven memory retention schedules.',
      highlights: ['Time-blocked daily study schedules', 'Active recall & spaced repetition', 'Weak subject booster strategies'],
    },
    {
      id: 'scholarship' as ToolType,
      title: 'AI Scholarship Assistant',
      icon: Award,
      color: 'from-cyan-500 to-blue-600',
      bgColor: 'bg-cyan-50 dark:bg-cyan-950/40',
      textColor: 'text-cyan-600 dark:text-cyan-400',
      borderColor: 'border-cyan-200 dark:border-cyan-800',
      description: 'Explore verified national & international scholarships (HEC, Ehsaas, PEEF, Chevening, Fulbright, DAAD) with document checklists.',
      highlights: ['Verified eligibility checklists', 'HEC & overseas document requirements', 'Statement of Purpose (SOP) guidance'],
    },
    {
      id: 'roadmap' as ToolType,
      title: 'AI Skill Roadmap Generator',
      icon: MapPin,
      color: 'from-emerald-500 to-teal-600',
      bgColor: 'bg-emerald-50 dark:bg-emerald-950/40',
      textColor: 'text-emerald-600 dark:text-emerald-400',
      borderColor: 'border-emerald-200 dark:border-emerald-800',
      description: 'Convert ambitious career goals into actionable week-by-week learning paths with free courses, projects, and certifications.',
      highlights: ['Phase-by-phase learning pathways', 'Free top-rated learning resources', 'Real-world project portfolio ideas'],
    },
    {
      id: 'resume' as ToolType,
      title: 'AI Resume Assistant',
      icon: FileCheck2,
      color: 'from-violet-500 to-purple-600',
      bgColor: 'bg-violet-50 dark:bg-violet-950/40',
      textColor: 'text-violet-600 dark:text-violet-400',
      borderColor: 'border-violet-200 dark:border-violet-800',
      description: 'Upload or paste your resume text to receive an instant ATS score, formatting review, section fixes, and strong action-verb bullet rewrites.',
      highlights: ['ATS compatibility score out of 100', 'Action-verb bullet rewrites', 'Target industry keyword matching'],
    },
    {
      id: 'interview' as ToolType,
      title: 'AI Interview Coach',
      icon: UserCheck,
      color: 'from-blue-600 to-cyan-600',
      bgColor: 'bg-sky-50 dark:bg-sky-950/40',
      textColor: 'text-sky-600 dark:text-sky-400',
      borderColor: 'border-sky-200 dark:border-sky-800',
      description: 'Prepare for technical and behavioral job or university admission interviews with model answers, STAR technique guides, and insider tips.',
      highlights: ['Behavioral & Technical questions', 'STAR model answer breakdowns', 'Pakistani & global hiring insider tips'],
    },
  ];

  return (
    <section id="features" className="py-16 md:py-20 relative bg-slate-100/50 dark:bg-slate-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-blue-100/80 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Comprehensive Student Toolkit</span>
          </div>
          <h2 className="font-outfit font-extrabold text-3xl sm:text-4xl text-slate-900 dark:text-white">
            6 Specialized AI Advisors in One Platform
          </h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400">
            Every feature is fine-tuned to help Pakistani students navigate education transitions, apply for scholarships, build career skills, and land top opportunities.
          </p>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feat) => {
            const IconComponent = feat.icon;
            return (
              <div
                key={feat.id}
                className="glass-card rounded-2xl p-6 flex flex-col justify-between hover:shadow-xl hover:shadow-blue-500/10 transition-all duration-300 group border border-slate-200/80 dark:border-slate-800"
              >
                <div>
                  {/* Icon & Title */}
                  <div className="flex items-center space-x-3 mb-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-tr ${feat.color} text-white flex items-center justify-center shadow-md`}>
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <h3 className="font-outfit font-bold text-lg text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                      {feat.title}
                    </h3>
                  </div>

                  {/* Description */}
                  <p className="text-sm text-slate-600 dark:text-slate-300 mb-4 leading-relaxed">
                    {feat.description}
                  </p>

                  {/* Key Highlights */}
                  <ul className="space-y-1.5 mb-6 text-xs text-slate-500 dark:text-slate-400">
                    {feat.highlights.map((item, idx) => (
                      <li key={idx} className="flex items-center space-x-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Button */}
                <button
                  onClick={() => {
                    onSelectTool(feat.id);
                    const el = document.getElementById('tools');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className={`w-full py-2.5 px-4 rounded-xl font-semibold text-xs sm:text-sm flex items-center justify-center space-x-2 border ${feat.borderColor} ${feat.bgColor} ${feat.textColor} hover:brightness-95 transition-all`}
                >
                  <span>Launch {feat.title}</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
