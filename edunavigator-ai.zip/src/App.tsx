import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { FeaturesSection } from './components/FeaturesSection';
import { Dashboard } from './components/Dashboard';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { SavedPlansModal } from './components/SavedPlansModal';
import { SearchModal } from './components/SearchModal';
import { ToolType, SavedPlan } from './types';
import { getSavedPlans } from './utils/storage';

export default function App() {
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('edunavigator_theme');
    return saved === 'dark' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches);
  });

  const [selectedTool, setSelectedTool] = useState<ToolType>('career');
  const [activeSection, setActiveSection] = useState<string>('hero');
  const [savedModalOpen, setSavedModalOpen] = useState<boolean>(false);
  const [searchModalOpen, setSearchModalOpen] = useState<boolean>(false);
  const [savedPlans, setSavedPlans] = useState<SavedPlan[]>([]);

  // Refresh saved plans list
  const refreshSavedPlans = () => {
    setSavedPlans(getSavedPlans());
  };

  useEffect(() => {
    refreshSavedPlans();
  }, []);

  // Synchronize Dark Mode class on <html> tag
  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
      localStorage.setItem('edunavigator_theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('edunavigator_theme', 'light');
    }
  }, [darkMode]);

  const handleSelectTool = (tool: ToolType) => {
    setSelectedTool(tool);
    setActiveSection('tools');
    const el = document.getElementById('tools');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col transition-colors duration-300">
      {/* Top Navbar */}
      <Navbar
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        savedCount={savedPlans.length}
        onOpenSavedModal={() => setSavedModalOpen(true)}
        onOpenSearchModal={() => setSearchModalOpen(true)}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
        onSelectTool={handleSelectTool}
      />

      {/* Main Page Layout */}
      <main className="flex-1">
        {/* Hero Section */}
        <HeroSection
          onStartClick={() => {
            setActiveSection('tools');
            const el = document.getElementById('tools');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          onExploreClick={() => {
            setActiveSection('features');
            const el = document.getElementById('features');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* AI Workspace Dashboard */}
        <Dashboard
          selectedTool={selectedTool}
          setSelectedTool={setSelectedTool}
          onPlanSaved={refreshSavedPlans}
        />

        {/* 6 AI Features Grid Section */}
        <FeaturesSection onSelectTool={handleSelectTool} />

        {/* About & Problem Solved Section */}
        <AboutSection />

        {/* FAQ & Contact Section */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Modals */}
      <SavedPlansModal
        isOpen={savedModalOpen}
        onClose={() => setSavedModalOpen(false)}
        savedPlans={savedPlans}
        onPlansUpdated={refreshSavedPlans}
      />

      <SearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onSelectTool={handleSelectTool}
        savedPlans={savedPlans}
        onOpenSavedModal={() => {
          setSearchModalOpen(false);
          setSavedModalOpen(true);
        }}
      />
    </div>
  );
}
