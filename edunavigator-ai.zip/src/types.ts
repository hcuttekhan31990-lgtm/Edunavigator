export type ToolType = 
  | 'career' 
  | 'study' 
  | 'scholarship' 
  | 'roadmap' 
  | 'resume' 
  | 'interview';

export interface SavedPlan {
  id: string;
  toolType: ToolType;
  title: string;
  date: string;
  content: string;
  inputsSummary: string;
}

export interface CareerAdvisorInputs {
  educationLevel: string;
  fieldOfStudy: string;
  interests: string;
  goals: string;
  preferredLocation: string;
  budgetConstraint: string;
}

export interface StudyPlannerInputs {
  subjects: string;
  targetExam: string;
  examDate: string;
  availableDailyHours: string;
  learningStyle: string;
  weakAreas: string;
}

export interface ScholarshipAssistantInputs {
  educationLevel: string;
  currentGPA: string;
  targetDegree: string;
  targetCountry: string;
  financialNeed: string;
  fieldOfInterest: string;
}

export interface SkillRoadmapInputs {
  targetRole: string;
  currentSkillLevel: string;
  timeframeMonths: string;
  weeklyHours: string;
}

export interface ResumeAssistantInputs {
  resumeText: string;
  targetJobTitle: string;
  experienceLevel: string;
}

export interface InterviewCoachInputs {
  jobRole: string;
  field: string;
  difficulty: string;
  customTopic: string;
}

export interface SearchItem {
  id: string;
  type: 'tool' | 'scholarship' | 'faq' | 'saved';
  title: string;
  category: string;
  description: string;
  action: () => void;
}
