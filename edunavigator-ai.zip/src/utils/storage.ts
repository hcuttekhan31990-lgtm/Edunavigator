import { SavedPlan, ToolType } from '../types';

const STORAGE_KEY = 'edunavigator_saved_plans_v1';

export function getSavedPlans(): SavedPlan[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error reading saved plans from localStorage:', error);
    return [];
  }
}

export function savePlan(toolType: ToolType, title: string, content: string, inputsSummary: string): SavedPlan {
  const plans = getSavedPlans();
  const newPlan: SavedPlan = {
    id: 'plan_' + Date.now(),
    toolType,
    title,
    date: new Date().toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }),
    content,
    inputsSummary,
  };

  const updated = [newPlan, ...plans];
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (error) {
    console.error('Error saving plan to localStorage:', error);
  }

  return newPlan;
}

export function deleteSavedPlan(id: string): SavedPlan[] {
  const plans = getSavedPlans();
  const updated = plans.filter((p) => p.id !== id);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (error) {
    console.error('Error deleting plan from localStorage:', error);
  }
  return updated;
}

export function clearAllSavedPlans(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error('Error clearing saved plans:', error);
  }
}
