import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Google Gen AI client safely
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY environment variable is not configured.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

const SYSTEM_PROMPT = `
You are EduNavigator AI, an expert, highly encouraging, and empathetic Academic & Career Planning Advisor for Pakistani and global students.

GUIDELINES:
1. Provide practical, step-by-step, realistic academic and career recommendations.
2. Incorporate deep context on educational paths (Matric, FSc Pre-Medical, Pre-Engineering, ICS, I.Com, A-Levels, BS/BE, MBBS, CA/ACCA, MS, MPhil, PhD).
3. Reference real, well-known scholarships (HEC Need-Based & Overseas, Ehsaas Undergraduate, PEEF, Sindh Endowment, USAID, Fulbright, Chevening, DAAD, Commonwealth, Erasmus Mundus, Turkiye Burslari, MEXT) and entrance tests (ECAT, MDCAT, NTS NAT/GAT, NUST NET, FAST Test, USAT, SAT, GRE).
4. NEVER invent fake scholarship names, eligibility criteria, or deadlines. If specific current-year dates are uncertain, explicitly state: "Please verify exact current deadlines on the official website."
5. Use clear, simple, accessible English with professional structure: bullet points, clean markdown headers, bold key concepts, and actionable checklists.
6. Be supportive, empathetic, and motivating.
`;

// API Routes
app.post('/api/ai/career-advisor', async (req, res) => {
  try {
    const { educationLevel, fieldOfStudy, interests, goals, preferredLocation, budgetConstraint } = req.body;

    if (!educationLevel || !interests || !goals) {
      return res.status(400).json({ error: 'Missing required fields: educationLevel, interests, goals' });
    }

    const ai = getGeminiClient();
    const prompt = `
Task: AI Career Advisor Guidance
Student Profile:
- Current Education Level: ${educationLevel}
- Field of Study / Stream: ${fieldOfStudy || 'Not specified'}
- Interests & Passions: ${interests}
- Future Career Goals: ${goals}
- Preferred Work / Study Location: ${preferredLocation || 'Pakistan / Global'}
- Budget / Financial Context: ${budgetConstraint || 'Flexible'}

Please provide a structured, comprehensive career recommendation containing:
1. 🎯 Top 3 Recommended Career Paths (with detailed reasons and industry demand in Pakistan & internationally)
2. 🎓 Recommended Degrees / Certifications & Top Universities (e.g., NUST, FAST, LUMS, UET, GIKI, COMSATS, Aga Khan, or Overseas)
3. 💡 Essential Technical & Soft Skills to Master
4. 🚀 Step-by-Step Action Plan (Short-term next 6 months, Medium-term 2-3 years)
5. 💰 Typical Salary & Growth Potential (in PKR & USD equivalent)
6. ⚠️ Potential Challenges & How to Overcome Them
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.7,
      },
    });

    res.json({ result: response.text });
  } catch (error: any) {
    console.error('Career Advisor Error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate career advice' });
  }
});

app.post('/api/ai/study-planner', async (req, res) => {
  try {
    const { subjects, targetExam, examDate, availableDailyHours, learningStyle, weakAreas } = req.body;

    if (!subjects || !availableDailyHours) {
      return res.status(400).json({ error: 'Missing required fields: subjects, availableDailyHours' });
    }

    const ai = getGeminiClient();
    const prompt = `
Task: Personalized AI Study Planner
Student Inputs:
- Subjects / Courses: ${subjects}
- Target Exam / Goal: ${targetExam || 'General Academic Improvement'}
- Exam Date / Timeline: ${examDate || 'Upcoming term'}
- Available Daily Study Hours: ${availableDailyHours} hours/day
- Preferred Learning Style: ${learningStyle || 'Visual & Practical'}
- Weak Areas / Main Blockers: ${weakAreas || 'Time management & complex topics'}

Generate a structured and highly realistic study strategy:
1. 📅 Daily Time-Blocked Schedule (morning, afternoon, evening slots matching ${availableDailyHours} hrs)
2. 🗓️ Weekly Study Routine Breakdown (subject distribution, revision cycles)
3. 🧠 Scientifically Proven Study Techniques to apply (Active Recall, Spaced Repetition, Pomodoro)
4. 📌 Focused Strategy for Weak Areas: ${weakAreas || 'None'}
5. 📚 Free Recommended Learning Resources (e.g. Khan Academy, YouTube channels, past paper strategies)
6. 🛑 Common Exam Prep Pitfalls to Avoid
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.7,
      },
    });

    res.json({ result: response.text });
  } catch (error: any) {
    console.error('Study Planner Error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate study plan' });
  }
});

app.post('/api/ai/scholarship-assistant', async (req, res) => {
  try {
    const { educationLevel, currentGPA, targetDegree, targetCountry, financialNeed, fieldOfInterest } = req.body;

    const ai = getGeminiClient();
    const prompt = `
Task: Verified Scholarship Guidance & Roadmap
Student Inputs:
- Education Level: ${educationLevel || 'Undergraduate'}
- Current Academic Standing / Marks / GPA: ${currentGPA || 'Not specified'}
- Target Degree: ${targetDegree || 'BS or MS'}
- Preferred Destination: ${targetCountry || 'Pakistan / International'}
- Financial Need Status: ${financialNeed || 'Need-Based'}
- Field of Interest: ${fieldOfInterest || 'General'}

Provide an accurate, honest scholarship roadmap:
1. 🌟 Top 4 Matching Real Scholarships (e.g., HEC Need-Based/Overseas, Ehsaas, PEEF, Sindh Endowment, USAID, Chevening, Fulbright, DAAD, Commonwealth, Turkiye Burslari, MEXT)
2. 📋 Precise Eligibility Criteria for each option
3. 📄 Required Documents Master Checklist (e.g., HEC Attestation, CNIC/B-Form, Income Certificate, Statement of Purpose (SOP), Recommendation Letters)
4. ⏰ Application Timelines & Deadlines Guidance (remind student to verify exact dates on official portals)
5. ✏️ Winning Application & SOP / Essay Preparation Tips
6. ⚠️ Important Warnings against fraud/scams (remind that real scholarships NEVER charge submission fees)
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.6,
      },
    });

    res.json({ result: response.text });
  } catch (error: any) {
    console.error('Scholarship Assistant Error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate scholarship advice' });
  }
});

app.post('/api/ai/skill-roadmap', async (req, res) => {
  try {
    const { targetRole, currentSkillLevel, timeframeMonths, weeklyHours } = req.body;

    if (!targetRole) {
      return res.status(400).json({ error: 'Missing targetRole' });
    }

    const ai = getGeminiClient();
    const prompt = `
Task: Step-by-Step AI Skill Roadmap
Target Role / Skill: ${targetRole}
Current Proficiency: ${currentSkillLevel || 'Beginner'}
Target Timeframe: ${timeframeMonths || 3} Months
Weekly Dedicated Hours: ${weeklyHours || 10} Hours/Week

Create an actionable, phase-by-phase learning roadmap:
1. 🗺️ Phase-by-Phase Roadmap Breakdown (e.g., Phase 1: Fundamentals, Phase 2: Core Concepts, Phase 3: Applied Projects & Portfolio)
2. 🛠️ Key Technologies, Tools, and Concepts to master in order
3. 💻 3 Hands-On Portfolio Project Ideas tailored to Pakistani & international hiring standards
4. 📚 Free Learning Resources (Documentation, top YouTube playlists, free courses)
5. 🏆 Recommended Industry Certifications to validate learning
6. 💼 How to showcasing these skills on LinkedIn & GitHub
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.7,
      },
    });

    res.json({ result: response.text });
  } catch (error: any) {
    console.error('Skill Roadmap Error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate skill roadmap' });
  }
});

app.post('/api/ai/resume-assistant', async (req, res) => {
  try {
    const { resumeText, targetJobTitle, experienceLevel } = req.body;

    if (!resumeText) {
      return res.status(400).json({ error: 'Please provide resume content or summary.' });
    }

    const ai = getGeminiClient();
    const prompt = `
Task: AI Resume Evaluation & Optimization
Target Job / Field: ${targetJobTitle || 'General Software / Business Role'}
Experience Level: ${experienceLevel || 'Student / Fresh Graduate'}
Resume Content Provided:
"""
${resumeText}
"""

Deliver a thorough resume review:
1. 📊 Estimated ATS & Overall Impact Score (Out of 100) with justification
2. ✅ Top Strengths identified
3. 🚨 Critical Areas for Improvement & Formatting Mistakes
4. 📝 Section-by-Section Enhancement Recommendations (Header, Summary, Experience, Education, Projects, Skills)
5. ⚡ Action Verb Bullet Point Rewrites (Give 3 concrete before/after examples using strong action verbs and quantified metrics)
6. 🎯 Targeted Industry Keywords to include for ATS passing
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.6,
      },
    });

    res.json({ result: response.text });
  } catch (error: any) {
    console.error('Resume Assistant Error:', error);
    res.status(500).json({ error: error.message || 'Failed to analyze resume' });
  }
});

app.post('/api/ai/interview-coach', async (req, res) => {
  try {
    const { jobRole, field, difficulty, customTopic } = req.body;

    if (!jobRole) {
      return res.status(400).json({ error: 'Missing jobRole' });
    }

    const ai = getGeminiClient();
    const prompt = `
Task: AI Interview Coach & Mock Preparation
Target Role: ${jobRole}
Industry / Domain: ${field || 'Tech / Engineering / Business'}
Difficulty Level: ${difficulty || 'Entry Level / Graduate'}
Specific Topic / Focus: ${customTopic || 'Comprehensive'}

Provide a high-yield interview preparation module:
1. ❓ Top 5 Behavioral & HR Questions (with key points the interviewer is looking for)
2. ⚙️ Top 5 Technical & Domain-Specific Questions (tailored to ${jobRole})
3. ⭐ Model STAR Method Responses (Situation, Task, Action, Result) for 2 tough questions
4. 💡 Insider Tips for Cracking Interviews in Pakistani & International companies
5. 🚩 Red Flags & Common Candidate Mistakes to avoid
6. ❓ Smart Questions the candidate should ask the interviewer at the end
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.7,
      },
    });

    res.json({ result: response.text });
  } catch (error: any) {
    console.error('Interview Coach Error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate interview prep' });
  }
});

app.post('/api/ai/general-chat', async (req, res) => {
  try {
    const { message, context } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    const ai = getGeminiClient();
    const prompt = `
Context from EduNavigator AI session: ${context || 'General academic or career inquiry'}
User Question: ${message}

Provide a clear, direct, friendly, and helpful response. Use clean markdown.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.7,
      },
    });

    res.json({ result: response.text });
  } catch (error: any) {
    console.error('General Chat Error:', error);
    res.status(500).json({ error: error.message || 'Failed to send message' });
  }
});

// Vite middleware for dev or static files for production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`EduNavigator AI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
