# EduNavigator AI – Student Success & Scholarship Planner

![EduNavigator AI Banner](https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=1200&auto=format&fit=crop)

An AI-powered academic and career planning web application designed to help Pakistani students make informed decisions regarding degrees, study routines, scholarships, skill development, resumes, and job interviews.

---

## 📌 Project Overview

**EduNavigator AI** addresses the real-world challenge of academic uncertainty and information fragmentation faced by students in Pakistan and developing regions. By providing 6 specialized AI advisors in a single modern interface, EduNavigator AI acts as a 24/7 personal academic counselor, study strategist, and scholarship assistant.

---

## 🎯 Real Problem Solved

1. **Career Confusion:** Students completing Matriculation, FSc Pre-Medical, Pre-Engineering, or ICS often lack structured guidance on modern job markets (Software Engineering, Data Science, Health Tech, Finance) vs traditional options.
2. **Scholarship Inaccessibility:** Thousands of deserving students miss out on major funding opportunities (HEC Need-Based, Ehsaas, PEEF, Fulbright, Chevening, DAAD) due to missing document deadlines or confusing eligibility requirements.
3. **Ineffective Exam Prep:** Cramming without scientifically backed routines leads to exam stress during Board or University Entry Tests (NUST NET, FAST NU, MDCAT, ECAT, NTS NAT/GAT).
4. **Resume & Interview Gaps:** Fresh graduates frequently fail initial screening due to non-ATS formatted resumes and lack of mock interview practice.

---

## ✨ Main Features & AI Workspaces

### 1. 🧭 AI Career Advisor
- Personalized career path recommendations based on academic stream (Matric, FSc, A-Levels, BS).
- Matches student passions with Pakistani market demand (NUST, FAST, LUMS, UET, GIKI) and global opportunities.
- Salary expectations in PKR and USD.

### 2. 📅 AI Study Planner
- Custom daily time-blocked study schedules and subject revision routines.
- Integrates Active Recall, Spaced Repetition, and Pomodoro techniques.
- Targeted strategies for weak subjects.

### 3. 🎓 AI Scholarship Assistant
- Verified guidance on national (HEC, Ehsaas, PEEF, Sindh Endowment) and international (Fulbright, Chevening, DAAD, Commonwealth, Turkiye Burslari) scholarships.
- Comprehensive document master checklist (HEC attestation, CNIC/B-Form, Income certificates, SOPs).
- Fraud prevention warnings against scam agencies.

### 4. 🗺️ AI Skill Roadmap Generator
- Phase-by-phase learning paths for target roles (Full Stack Dev, Data Science, Cyber Security, Graphic Design).
- Portfolio project ideas and free learning resource links.

### 5. 📄 AI Resume Assistant
- Estimated ATS score (out of 100) with section-by-section audit.
- Action-verb bullet point rewrites and keyword matching.

### 6. 🎙️ AI Interview Coach
- Behavioral & technical interview questions tailored to Pakistani & global companies.
- STAR method model answers and interviewer tips.

---

## 🛠️ Tech Stack & Architecture

- **Frontend:** HTML5, CSS3 (Tailwind CSS, Glassmorphism UI), TypeScript, React 19
- **Icons & Motion:** Lucide React, CSS Transitions & Keyframe Animations
- **AI Engine:** Google Gemini 3.6 Flash (`@google/genai` SDK)
- **Backend:** Node.js, Express.js (Server-side API routes for Gemini key protection)
- **PDF Export:** jsPDF
- **Persistence:** Browser Local Storage
- **Build Tooling:** Vite, ESBuild, TSX

---

## 🤖 AI System Prompt Safety & Standards

The underlying Gemini system prompt strictly enforces:
- Accurate, evidence-based career guidance.
- Absolute rejection of invented or fake scholarship details.
- Clear statements of uncertainty with official portal verification reminders.
- Simple, accessible English with a supportive tone.

---

## 💻 Local Installation & Setup

1. **Clone the repository:**
   ```bash
   git clone https://github.com/your-username/edunavigator-ai.git
   cd edunavigator-ai
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Configure Environment Variables:**
   Create a `.env` file in the root directory (refer to `.env.example`):
   ```env
   GEMINI_API_KEY="your_google_gemini_api_key_here"
   ```

4. **Run Development Server:**
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000` in your browser.

---

## 🚀 Deployment Guide (Vercel / Cloud Run)

### Deploying to Vercel
1. Push your code to GitHub.
2. Import your repository into Vercel.
3. Add `GEMINI_API_KEY` under **Project Settings > Environment Variables**.
4. Click **Deploy**.

---

## 📸 Screenshots & Previews

| Workspace Dashboard | Scholarship Assistant |
|:---:|:---:|
| *(Screenshot Placeholder: Modern Blue Glassmorphism Dashboard)* | *(Screenshot Placeholder: Verified HEC & Overseas Scholarship Checklist)* |

| Skill Roadmap Generator | Resume Reviewer & ATS Score |
|:---:|:---:|
| *(Screenshot Placeholder: Week-by-Week Learning Pathways)* | *(Screenshot Placeholder: ATS Audit & Bullet Rewrites)* |

---

## 🔗 Live Demo & GitHub

- **Live Application:** [https://edunavigator-ai.vercel.app](https://edunavigator-ai.vercel.app)
- **GitHub Repository:** [https://github.com/your-username/edunavigator-ai](https://github.com/your-username/edunavigator-ai)

---

## 📄 License

This project is open-source and created as a University Final Year Capstone Project.
